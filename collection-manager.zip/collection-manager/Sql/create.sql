

-- Create the music artists table
CREATE TABLE artists (
  artist_id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL
);

-- Create the albums table with a foreign key reference to artists
CREATE TABLE albums (
  album_id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  price NUMERIC(10, 2) NOT NULL,
  genre VARCHAR(100)
);

CREATE TABLE artist_albums(
	collection_id SERIAL PRIMARY KEY,
  artist_id SERIAL,
  album_id SERIAL,
  date_added VARCHAR(100),
  FOREIGN KEY (artist_id) REFERENCES artists(artist_id),
  FOREIGN KEY (album_id) REFERENCES albums(album_id)
)

-- Insert sample data into the artist table
INSERT INTO artists (name) VALUES
  ('Michael Jackson'),
  ('Amy Winehouse'),
  ('Beyonce'),
  ('Pink Sweat$'),
  ('Christian Paul');

-- Insert sample data into the album table
INSERT INTO albums (title, description, price, genre, artist_id) VALUES
  ('Thriller', 'The sixth studio album by American singer Michael Jackson. It was released on November 30', 9.99, 'R&B', 1),
  ('Back to Black', 'The second and final studio album by British singer Amy Winehouse, released on October 27, 2006.', 11.99, 'Pop', 2),
  ('Lemonade', 'The sixth studio album by American singer Beyoncé, released on April 23, 2016.', 12.99, 'Hip-Hop', 3),
  ('17', '"17" is a soulful and intimate album by Pink Sweat$, featuring heartfelt tracks that delve into personal experiences, emotions, and relationships.', 12.99, 'R&B', 4),
  ('Christian Paul', 'This album showcases a unique blend of contemporary R&B and pop, featuring soulful vocals and emotionally resonant lyrics.', 11.99, 'Pop', 5);

-- Insert sample data into the artist_albums table
INSERT INTO artist_albums (artist_id, album_id, date_added) VALUES
  (1, 1, '10-23-2010'),
  (2, 2, '08-12-2023'),
  (3, 3, '07-07-2021'),
  (4, 4, '01-24-2020'),
  (5, 5, '06-05-2019');
