const express = require('express');
const db = require('../db');

const router = express.Router();

// Home page

router.get('/', (req, res) => {
  res.render('index', { title: 'Album Collection Manager' });
});

router.get('/albums', async (req, res) => {
  const params = [];
  let query =
    'SELECT albums.title AS title, albums.genre AS genre, artists.name AS name, artist_albums.date_added FROM albums INNER JOIN artist_albums ON albums.album_id = artist_albums.album_id INNER JOIN artists ON artist_albums.artist_id = artists.artist_id';
  if (req.query.title) {
    query += ' WHERE title ILIKE $1';
    params.push('%' + req.query.title + '%');
  } else if (req.query.name) {
    query += ' WHERE name ILIKE $1';
    params.push('%' + req.query.name + '%');
  } else if (req.query.genre) {
    query += ' WHERE genre ILIKE $1';
    params.push('%' + req.query.genre + '%');
  } else if (req.query.date_added) {
    query += ' WHERE date_added = $1';
    params.push(req.query.date_added);
  }
  console.log('SQL Query:', query); // Add this line for debugging

  // Handle sorting
  if (req.query.sort === 'title') {
    query += ' ORDER BY title';
  } else if (req.query.sort === 'name') {
    query += ' ORDER BY name';
  } else if (req.query.sort === 'genre') {
    query += ' ORDER BY genre';
  } else if (req.query.sort === 'date_added') {
    query += ' ORDER BY date_added';
  }

  // Check the order parameter
  if (req.query.order === 'desc') {
    query += ' DESC'; // Sort in descending order
  }

  const result = await db.query(query, params);
  console.log(result.rows);
  res.render('albums', { title: 'Albums', rows: result.rows });
});

// New product form
router.get('/albums/create', (req, res) => {
  res.render('albums-create');
});

// Store new album and artist
const {
  insertAlbumsIntoDatabase,
  insertArtistsIntoDatabase,
  insertDateIntoDatabase,
} = require('../db'); // Adjust the path as needed

router.post('/albums', async (req, res) => {
  try {
    // res.json(req.body);

    const title = req.body.title;
    const name = req.body.name;
    const genre = req.body.genre;
    const dateAdded = req.body.date_added;
    const description = req.body.description;
    const price = req.body.price;
    // res.json(req.body);
    // Insert album data
    const albumResult = await insertAlbumsIntoDatabase(
      title,
      genre,
      price,
      description,
    );
    const albumId = albumResult.rows[0].album_id;
    console.log("this is albumid: " + albumId);
    console.log(albumResult);


    // Insert artist data
    const artistResult = await insertArtistsIntoDatabase(
      name,
    );
    console.log(artistResult);

    const artistId = artistResult.rows[0].artist_id;
    console.log(" this is artistid: " + artistId);

    // Insert date data
    await insertDateIntoDatabase(
      artistId,
      albumId,
      dateAdded,
    );
    console.log(dateAdded);

    res.redirect('/albums');
  } catch (error) {
    console.error('Error inserting an album and artist:', error);
  }
});

// Define a route for displaying album details
router.get('/albums/details/:title', async (req, res) => {
  try {
    const albumTitle = req.params.title;
    const albumDetails = await db.fetchAlbumDetailsByTitleFromDatabase(
      albumTitle
    ); // Use the correct function name
    console.log('Album Details:', albumDetails); // Add this line for debugging

    if (albumDetails) {
      res.render('album-detail', {
        title: 'Album Details',
        album: albumDetails,
      });
    } else {
      // Handle the case where the album is not found
      res.status(404).send('Album not found');
    }
  } catch (error) {
    console.error('Error fetching album details:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Add a new route to display the update form for a specific collectable
router.get('/albums/update/:title', async (req, res) => {
  try {
    const albumTitle = req.params.title;
    const albumDetails = await db.fetchAlbumDetailsByTitleFromDatabase(albumTitle);

    if (albumDetails) {
      res.render('albums-update', {
        title: 'Update Album',
        album: albumDetails,
      });
    } else {
      res.status(404).send('Album not found');
    }
  } catch (error) {
    console.error('Error fetching album details:', error);
    res.status(500).send('Internal Server Error');
  }
});


router.post('/albums/update/:title', async (req, res) => {
  try {
    const oldTitle = req.params.title; // Get the old title from the URL

    // Extract the new values from the form
    const title = req.body.title;
    const name = req.body.name;
    const genre = req.body.genre;
    const dateAdded = req.body.date_added;
    const description = req.body.description;
    const price = req.body.price;

    // Construct the update query
    const updateResult = await db.updateCollectableInDatabase(
      db,
      oldTitle, 
      title,
      name,
      genre,
      dateAdded,
      description,
      price
    );

    if (updateResult) {
      // The update was successful
      res.redirect(`/albums/details/${title}`);
    } else {
      // Handle the case where the collectable is not found
      res.status(404).send('Album not found');
    }
  } catch (error) {
    console.error('Error updating collectable:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Add this route at the bottom of your users.js file
router.post('/albums/delete/:title', async (req, res) => {
  try {
    const albumTitleToDelete = req.params.title; // Get the album title from the URL

    // Add a confirmation prompt
    const userConfirmation = req.body.confirmation;
    console.log(userConfirmation);
    if (userConfirmation === 'Yes') {
      // Perform the deletion
      await db.deleteAlbumByTitleFromDatabase(albumTitleToDelete);

      // Redirect to the albums listing page after successful deletion
      res.redirect('/albums');
    } else {
      // Redirect back to the details page if deletion is not confirmed
      res.redirect(`/`);
    }
  } catch (error) {
    console.error('Error deleting album:', error);
    res.status(500).send('Internal Server Error');
  }
});




module.exports = router;
