const { Pool } = require('pg');

const pool = new Pool({ ssl: { rejectUnauthorized: false } });

if (
  !(
    process.env.PGUSER &&
    process.env.PGPASSWORD &&
    process.env.PGDATABASE &&
    process.env.PGHOST &&
    process.env.PGPORT
  )
) {
  console.error(
    'Database settings are not set.  Confirm your .env file is correct.'
  );
}

const insertAlbumsIntoDatabase = async ( title, genre, price, description ) => {
  try {
    console.log(title, genre, price, description);
    const client = await pool.connect();
    const result = await client.query(
      'INSERT INTO albums (title, genre, price, description) VALUES ($1, $2, $3, $4) RETURNING album_id',
      [title, genre, price, description]
    );
    client.release();
    return result; 
  } catch (error) {
    console.error('Error inserting an album:', error);
    throw error;
  }
};

const insertArtistsIntoDatabase = async (name) => {
  try {
    console.log(name);
    const client = await pool.connect();
    const result = await client.query(
      'INSERT INTO artists (name) VALUES ($1) RETURNING artist_id',
      [name]
    );
    client.release();
    return result;
  } catch (error) {
    console.error('Error inserting an artist:', error);
    throw error;
  }
};

const insertDateIntoDatabase = async (artist_id, album_id, date_added) => {
  try {
    console.log(artist_id, album_id, date_added);
    const client = await pool.connect();
    await client.query(
      'INSERT INTO artist_albums (artist_id, album_id, date_added) VALUES ($1, $2, $3)',
      [artist_id, album_id, date_added]
    );
    client.release();
  } catch (error) {
    console.error('Error inserting a date:', error);
    throw error;
  }
};

async function fetchAlbumDetailsByTitleFromDatabase(albumTitle) {
  try {
    const client = await pool.connect();

    const query = `
      SELECT albums.album_id, albums.title, albums.genre, albums.description, 
      artists.name, albums.price, artist_albums.date_added AS date_added
      FROM albums
      INNER JOIN artist_albums ON albums.album_id = artist_albums.album_id
      INNER JOIN artists ON artist_albums.artist_id = artists.artist_id
      WHERE albums.title = $1`;

    const values = [albumTitle];

    const result = await client.query(query, values);

    client.release();

    if (result.rows.length > 0) {
      return result.rows[0];
    } 
      return null;
    
  } catch (error) {
    console.error('Error fetching album details:', error);
    throw error;
  }
}

async function updateCollectableInDatabase(db, oldTitle, newTitle, newName, newGenre, newDateAdded, newDescription, newPrice) {
  try {
    // Update the album table
    const updateAlbumQuery = `
      UPDATE albums
      SET title = $1, genre = $2, description = $3, price = $4
      WHERE title = $5
    `;

    await db.query(updateAlbumQuery, [newTitle, newGenre, newDescription, newPrice, oldTitle]);

    // Update the artist table
    const updateArtistQuery = `
      UPDATE artists
      SET name = $1
      WHERE artist_id = (SELECT artist_id FROM artist_albums WHERE album_id = (SELECT album_id FROM albums WHERE title = $2 LIMIT 1))
    `;

    await db.query(updateArtistQuery, [newName, newTitle]);

    // Update the artist_albums table
    const updateArtistAlbumsQuery = `
      UPDATE artist_albums
      SET date_added = $1
      WHERE album_id = (SELECT album_id FROM albums WHERE title = $2 LIMIT 1)
    `;

    await db.query(updateArtistAlbumsQuery, [newDateAdded, newTitle]);

    return true; // Return true or a success message if needed
  } catch (error) {
    throw error;
  }
}

async function deleteAlbumByTitleFromDatabase(albumTitle) {
  try {
    const client = await pool.connect();

    const deleteQuery = 'DELETE FROM albums WHERE title = $1';
    const values = [albumTitle];

    const result = await client.query(deleteQuery, values);

    client.release();

    // Check if any rows were affected
    return result.rowCount > 0;
  } catch (error) {
    console.error('Error deleting album from database:', error);
    throw error;
  }
}



module.exports = {
  query: (text, params) => {
    console.log('QUERY:', text);
    console.log('PARAMS:', JSON.stringify(params));
    return pool
      .query(text, params)
      .then((result) => {
        console.log('RESULT ROWS: ', result.rows);
        return result;
      })
      .catch((exception) => console.log(exception));
  },
  insertAlbumsIntoDatabase,
  insertArtistsIntoDatabase,
  insertDateIntoDatabase,
  fetchAlbumDetailsByTitleFromDatabase,
  updateCollectableInDatabase,
  deleteAlbumByTitleFromDatabase,
};
